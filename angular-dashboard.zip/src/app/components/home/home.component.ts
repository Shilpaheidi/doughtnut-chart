import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {
  text1 = '$1200';

  subtitles = { text: 'total' };
  chartOptions = {
    animationEnabled: true,
    theme: 'dark2',

    // title: {
    //   text: `${this.text1}  \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                                                                                                                            \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n ${this.text2}`,

    //   verticalAlign: 'center',
    //   horizontalAlign: 'center',
    //   fontSize: 12,
    //   fontFamily: 'Arial',
    //   fontWeight: 'bold',
    //   fontColor: this.text1 = 'white',
    //   fontColor1: (this.text2 = 'black'),
    // },
    // subtitles: [
    //   {
    //     text: `${this.text3}`,
    //     verticalAlign: 'center',
 
    //   },
  
    // ],
    title: {
      text: `${this.text1} ${this.subtitles.text}`,
      verticalAlign: 'center',
      horizontalAlign: 'center',
      maxWidth: 60,
      fontColor: 'white', // Set the main title font color
    },
   
  
      
    backgroundColor: '#0f172a',

    data: [
      {
        type: 'doughnut',
        ValueFormatString: "#,###.##'%'",
        dataPoints: [
          { y: 90, color: 'black' }, // Black color for the third data point
          { y: 39, color: '#008000' }, // Green color for the first data point
          { y: 33, color: 'orange' }, // Yellow color for the second data point
        ],
      },
    ],
  };
}
